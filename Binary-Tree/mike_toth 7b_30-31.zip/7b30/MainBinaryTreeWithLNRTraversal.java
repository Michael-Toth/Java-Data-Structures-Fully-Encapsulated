
public class MainBinaryTreeWithLNRTraversal
{public static void main(String[] args)
 {BinaryTreeWithLNRTraversal t = new BinaryTreeWithLNRTraversal();
   Listing l;
   Listing l1  = new Listing("Ann",    "1",  "1");
   Listing l2  = new Listing("Bill",     "2",  "2" );
   Listing l3  = new Listing("Carol",  "3 ",  "4");
   Listing l4  = new Listing("Mike",   "4 ",  "4");
   Listing l5  = new Listing("Pat",      "5 ",  "4");
   Listing l6  = new Listing("Sally",   "6 ",  "3");
   Listing l7  = new Listing("Ted",     "7 ",  "2");
   Listing l8  = new Listing("Vick",   "8 ",  "2");
   Listing l9  = new Listing("Will",   "9 ",  "2");
   Listing l10 = new Listing("Zack",  "11 ", "3");
   Listing l11 = new Listing("Zeek",  "22 ", "3");
 // insert the nodes 
   t.insert(l9);
   t.insert(l7);
   t.insert(l10);
   t.insert(l2);
   t.insert(l8);
   t.insert(l1);
   t.insert(l4);
   t.insert(l3);
   t.insert(l6);
   t.insert(l5);
//Output all the nodes in LNR (assending) order 
   t.showAll();
   System.out.println("\nNow making some deletions:");
   t.delete("Will");
//   t.delete("Ted");
//   t.delete("Zack");
       t.update("Carol",l11);
  /* t.delete("Vick");
   t.delete("Ann");
   t.delete("Mike");*/
//Output all the nodes in LNR (assending) order 
   t.showAll();
  
   System.exit(0);
 }
}

